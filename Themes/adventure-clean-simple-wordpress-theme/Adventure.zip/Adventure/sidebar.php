					<div id="sidebar">
						<!-- Sidebar widget -->
						<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('adventure-main-page-sidebar') ) : else : ?>		
						<?php endif; ?>
					</div><!-- End sidebar. -->