					<div id="sidebar">
						<!-- Sidebar widget -->
						<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('adventure-main-blog-sidebar') ) : else : ?>		
						<?php endif; ?>
					</div><!-- End sidebar. -->