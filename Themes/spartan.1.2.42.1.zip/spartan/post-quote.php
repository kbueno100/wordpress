
												<div class="postquote">
                                                
                                                    <div class="post_entry">

														<div class="entry">
															
															<?php the_content(__('<span>Continue Reading >></span>', 'Spartan')); ?>
                                                            
                                                            <div class="postquoteperma">
                                                            
                                                                <a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'Spartan' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark"><?php the_time(get_option( 'date_format' )) ?></a>	                                                    
                                                            </div>  
                                                                                                                      
														</div>
													
													</div>
                                                    
                                               </div>
                                                                                                       