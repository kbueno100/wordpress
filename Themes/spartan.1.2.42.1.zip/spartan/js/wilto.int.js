// JavaScript Document
                                    jQuery(document).ready(function(){
										
										jQuery.noConflict();
										
										jQuery('#Main_nav').tinyNav({
                                        header: true
                                      });
									});

                                   
								   jQuery(document).ready(function(){
									jQuery.noConflict();
								   
								   		jQuery('.slidewrap2').carousel({
                                            slider: '.slider',
                                            slide: '.slide',
                                            addNav: true,
                                            addPagination: true,
                                            speed: 300 // ms.
                                        });
								   
								   
								   });
								   
								   