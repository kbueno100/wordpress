



                </div>	
                <!-- Content Section ends here -->	
                
                <!-- Footer Section starts here -->
                <div id="footer_section">
                    
                    
                                            <div id="bottomfooterwidgetcontainer">
                                                <div class="bottomfooterwidgety">

                                                        <div class="footerp"><?php _e('&copy; All rights reserved.', 'Spartan') ?></div>
                                                        <?php if( is_home() || is_front_page() ): ?>
                                                        <div class="footercredit">
															<?php _e('Powered by ', 'Spartan') ?><a href="http://www.wordpress.org/"><?php _e('WordPress', 'Spartan') ?></a><?php _e(' & ', 'Spartan') ?><a href="http://www.themealley.com/"><?php _e('Spartan Theme', 'Spartan') ?></a>
                                                        </div>
                                                        <?php else: ?>
                                                        <div class="footercredit">
															<?php _e('Powered by ', 'Spartan') ?><a href="http://www.wordpress.org/"><?php _e('WordPress', 'Spartan') ?></a>
                                                        </div>                                                        
														<?php endif;?>
                                                </div>
                                            </div>	                
                    
                    
                    
                    
           
                 </div>	
                 <!-- Footer Section ends here -->	
                                                              
			</div>	
			<!-- Wrapper two ends here -->	
            
		</div>	
		<!-- Wrapper three ends here -->           
	</div>	
	<!-- Wrapper four ends here -->	            				
	</div>	
	<!-- Wrapper one ends here -->	


<?php wp_footer(); ?>
</body>
</html>