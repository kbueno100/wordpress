
<div id="footer" class="fullspan">

	<div class="container_16">
		<div class="grid_8 powered">
			<p>&copy; <?php echo date('Y'); ?> <?php bloginfo(); ?>. <?php _e('Powered by',woothemes); ?> <a href="http://www.wordpress.org" title="WordPress">WordPress</a></p>
		</div>
        <div class="grid_8 omega credit">
			<p><a href="http://www.woothemes.com">Snapshot Theme</a> <?php _e('by',woothemes); ?> <a href="http://www.woothemes.com" title="WooThemes - Premium WordPress Themes"><img src="<?php bloginfo('template_directory'); ?>/images/design/woothemes.png" alt="WooThemes - Premium WordPress Themes" /></a></p>
		</div>
	</div><!-- /container_16 -->

</div><!-- /footer -->

</div><!-- /wrap -->

<?php wp_footer(); ?>



</body>
</html>