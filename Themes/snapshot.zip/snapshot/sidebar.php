<div class="grid_4 omega">
    <div id="sidebar">
        
        <div id="largewidget" class="widgetlist alpha grid_4">
        
            <?php if (function_exists('woo_sidebar') && woo_sidebar(1) ) : else : ?>		
            
            <?php endif; ?>        
        
        </div>
        
    </div><!-- /sidebar -->
</div><!-- /grid 6 -->
